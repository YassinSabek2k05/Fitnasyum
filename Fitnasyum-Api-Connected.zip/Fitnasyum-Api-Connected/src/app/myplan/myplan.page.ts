import { Component } from '@angular/core';

@Component({
  selector: 'app-myplan',
  templateUrl: 'myplan.page.html',
  styleUrls: ['myplan.page.scss'],
  standalone: false,
})
export class MyplanPage {
  constructor() { }
}
